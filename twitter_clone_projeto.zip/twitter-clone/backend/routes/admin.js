// routes/admin.js — Backoffice do Administrador
const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// Todas as rotas admin requerem autenticação E ser admin
router.use(authMiddleware, adminMiddleware);

// GET /api/admin/utilizadores — Listar todos os utilizadores
router.get('/utilizadores', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT u.utilizador_id, u.username, u.email, u.is_admin, u.ativo, u.data_registo,
             COUNT(t.tweet_id) AS total_tweets
      FROM UTILIZADOR u
      LEFT JOIN TWEET t ON t.utilizador_id = u.utilizador_id
      GROUP BY u.utilizador_id
      ORDER BY u.data_registo DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao carregar utilizadores.' });
  }
});

// PUT /api/admin/utilizadores/:id — Editar utilizador
router.put('/utilizadores/:id', async (req, res) => {
  const { id } = req.params;
  const { bio, is_admin, ativo } = req.body;

  try {
    await db.query(
      'UPDATE UTILIZADOR SET bio = ?, is_admin = ?, ativo = ? WHERE utilizador_id = ?',
      [bio, is_admin ? 1 : 0, ativo ? 1 : 0, id]
    );
    res.json({ message: 'Utilizador atualizado com sucesso.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao atualizar utilizador.' });
  }
});

// DELETE /api/admin/utilizadores/:id — Apagar utilizador
router.delete('/utilizadores/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM UTILIZADOR WHERE utilizador_id = ?', [id]);
    res.json({ message: 'Utilizador apagado com sucesso.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao apagar utilizador.' });
  }
});

// GET /api/admin/tweets — Listar todos os tweets
router.get('/tweets', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT t.tweet_id, t.conteudo, t.imagem_url, t.data_publicacao,
             u.username, u.utilizador_id,
             COUNT(g.utilizador_id) AS total_gostos
      FROM TWEET t
      INNER JOIN UTILIZADOR u ON t.utilizador_id = u.utilizador_id
      LEFT JOIN GOSTO g ON g.tweet_id = t.tweet_id
      GROUP BY t.tweet_id
      ORDER BY t.data_publicacao DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao carregar tweets.' });
  }
});

// DELETE /api/admin/tweets/:id — Apagar tweet (admin)
router.delete('/tweets/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM TWEET WHERE tweet_id = ?', [id]);
    res.json({ message: 'Tweet apagado com sucesso.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao apagar tweet.' });
  }
});

module.exports = router;
