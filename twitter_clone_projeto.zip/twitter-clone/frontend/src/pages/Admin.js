// src/pages/Admin.js — Backoffice do Administrador
import { useState, useEffect } from 'react';
import {
  adminGetUtilizadores, adminApagarUtilizador, adminEditarUtilizador,
  adminGetTweets, adminApagarTweet
} from '../services/api';

export default function Admin() {
  const [tab, setTab] = useState('utilizadores');
  const [utilizadores, setUtilizadores] = useState([]);
  const [tweets, setTweets] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarDados();
  }, [tab]);

  const carregarDados = async () => {
    setCarregando(true);
    try {
      if (tab === 'utilizadores') {
        const { data } = await adminGetUtilizadores();
        setUtilizadores(data);
      } else {
        const { data } = await adminGetTweets();
        setTweets(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCarregando(false);
    }
  };

  const toggleAtivo = async (u) => {
    try {
      await adminEditarUtilizador(u.utilizador_id, {
        bio: u.bio, is_admin: u.is_admin, ativo: !u.ativo
      });
      setUtilizadores(prev => prev.map(x =>
        x.utilizador_id === u.utilizador_id ? { ...x, ativo: !x.ativo } : x
      ));
    } catch (err) { alert('Erro ao atualizar.'); }
  };

  const apagarUtilizador = async (id) => {
    if (!window.confirm('Apagar utilizador e todos os seus dados?')) return;
    try {
      await adminApagarUtilizador(id);
      setUtilizadores(prev => prev.filter(u => u.utilizador_id !== id));
    } catch (err) { alert('Erro ao apagar.'); }
  };

  const apagarTweet = async (id) => {
    if (!window.confirm('Apagar este tweet?')) return;
    try {
      await adminApagarTweet(id);
      setTweets(prev => prev.filter(t => t.tweet_id !== id));
    } catch (err) { alert('Erro ao apagar.'); }
  };

  return (
    <>
      <div className="page-header"><h2>⚙️ Backoffice</h2></div>
      <div className="admin-page">
        <div className="admin-tabs">
          <button className={`btn-${tab === 'utilizadores' ? 'primary' : 'outline'}`} onClick={() => setTab('utilizadores')}>
            👥 Utilizadores
          </button>
          <button className={`btn-${tab === 'tweets' ? 'primary' : 'outline'}`} onClick={() => setTab('tweets')}>
            🐦 Tweets
          </button>
        </div>

        {carregando ? <div className="spinner" /> : tab === 'utilizadores' ? (
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th><th>Username</th><th>Email</th>
                <th>Admin</th><th>Estado</th><th>Tweets</th><th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {utilizadores.map(u => (
                <tr key={u.utilizador_id}>
                  <td>{u.utilizador_id}</td>
                  <td><strong>@{u.username}</strong></td>
                  <td style={{ color: 'var(--text-secondary)' }}>{u.email}</td>
                  <td>{u.is_admin ? <span className="badge badge-admin">Admin</span> : '—'}</td>
                  <td>
                    <span className={`badge ${u.ativo ? 'badge-ativo' : 'badge-inativo'}`}>
                      {u.ativo ? 'Ativo' : 'Inativo'}
                    </span>
                  </td>
                  <td>{u.total_tweets}</td>
                  <td style={{ display: 'flex', gap: 6 }}>
                    <button className="btn-outline" style={{ padding: '4px 12px', fontSize: 13 }} onClick={() => toggleAtivo(u)}>
                      {u.ativo ? 'Desativar' : 'Ativar'}
                    </button>
                    <button className="btn-danger" style={{ padding: '4px 12px', fontSize: 13 }} onClick={() => apagarUtilizador(u.utilizador_id)}>
                      Apagar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <table className="admin-table">
            <thead>
              <tr><th>ID</th><th>Autor</th><th>Conteúdo</th><th>Gostos</th><th>Data</th><th>Ação</th></tr>
            </thead>
            <tbody>
              {tweets.map(t => (
                <tr key={t.tweet_id}>
                  <td>{t.tweet_id}</td>
                  <td><strong>@{t.username}</strong></td>
                  <td style={{ maxWidth: 260, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {t.conteudo}
                  </td>
                  <td>❤️ {t.total_gostos}</td>
                  <td style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
                    {new Date(t.data_publicacao).toLocaleDateString('pt-PT')}
                  </td>
                  <td>
                    <button className="btn-danger" style={{ padding: '4px 12px', fontSize: 13 }} onClick={() => apagarTweet(t.tweet_id)}>
                      Apagar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
