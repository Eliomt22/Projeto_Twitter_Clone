// src/components/Layout.js — Layout com sidebar
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Layout() {
  const { utilizador, logout } = useAuth();
  const navigate = useNavigate();

  const inicial = utilizador?.username?.[0]?.toUpperCase() || '?';

  return (
    <div className="layout">
      {/* ── Sidebar ── */}
      <aside className="sidebar">
        <div className="sidebar-logo">𝕏</div>

        <nav className="sidebar-nav">
          <NavLink to="/feed" className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}>
            <span className="nav-icon">🏠</span>
            <span className="nav-label">Início</span>
          </NavLink>

          <NavLink to="/explorar" className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}>
            <span className="nav-icon">🔍</span>
            <span className="nav-label">Explorar</span>
          </NavLink>

          <NavLink
            to={`/perfil/${utilizador?.username}`}
            className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <span className="nav-icon">👤</span>
            <span className="nav-label">Perfil</span>
          </NavLink>

          {utilizador?.is_admin === 1 && (
            <NavLink to="/admin" className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}>
              <span className="nav-icon">⚙️</span>
              <span className="nav-label">Admin</span>
            </NavLink>
          )}
        </nav>

        <div className="sidebar-tweet-btn">
          <button
            className="btn-primary"
            style={{ width: '100%', padding: '14px' }}
            onClick={() => navigate('/feed')}
          >
            Tweetar
          </button>
        </div>

        {/* Utilizador logado */}
        <div className="sidebar-user" onClick={logout} title="Clica para sair">
          <div className="avatar">
            {utilizador?.foto_perfil
              ? <img src={utilizador.foto_perfil} alt={utilizador.username} />
              : inicial}
          </div>
          <div className="sidebar-user-info">
            <div className="sidebar-user-name">{utilizador?.username}</div>
            <div className="sidebar-user-handle">@{utilizador?.username}</div>
          </div>
          <span>↩</span>
        </div>
      </aside>

      {/* ── Conteúdo ── */}
      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
}
