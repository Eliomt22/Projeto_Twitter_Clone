// src/components/TweetCard.js — Cartão de tweet individual
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toggleGosto, apagarTweet } from '../services/api';

function formatarData(dataStr) {
  const data = new Date(dataStr);
  const agora = new Date();
  const diff = (agora - data) / 1000;
  if (diff < 60)    return `${Math.floor(diff)}s`;
  if (diff < 3600)  return `${Math.floor(diff/60)}m`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h`;
  return data.toLocaleDateString('pt-PT', { day: 'numeric', month: 'short' });
}

export default function TweetCard({ tweet, onApagado }) {
  const { utilizador } = useAuth();
  const navigate = useNavigate();
  const [gostos, setGostos] = useState(Number(tweet.total_gostos) || 0);
  const [euGostei, setEuGostei] = useState(Boolean(tweet.eu_gostei));
  const [apagando, setApagando] = useState(false);

  const handleGosto = async (e) => {
    e.stopPropagation();
    try {
      const { data } = await toggleGosto(tweet.tweet_id);
      setEuGostei(data.gostou);
      setGostos(prev => data.gostou ? prev + 1 : prev - 1);
    } catch (err) {
      console.error('Erro ao dar gosto:', err);
    }
  };

  const handleApagar = async (e) => {
    e.stopPropagation();
    if (!window.confirm('Tens a certeza que queres apagar este tweet?')) return;
    setApagando(true);
    try {
      await apagarTweet(tweet.tweet_id);
      onApagado?.(tweet.tweet_id);
    } catch (err) {
      alert(err.response?.data?.error || 'Erro ao apagar.');
      setApagando(false);
    }
  };

  const podeApagar = utilizador?.utilizador_id === tweet.utilizador_id || utilizador?.is_admin === 1;

  return (
    <article
      className="tweet-card"
      onClick={() => navigate(`/perfil/${tweet.username}`)}
    >
      {/* Avatar */}
      <div
        className="avatar"
        onClick={e => { e.stopPropagation(); navigate(`/perfil/${tweet.username}`); }}
      >
        {tweet.foto_perfil
          ? <img src={tweet.foto_perfil} alt={tweet.username} />
          : tweet.username?.[0]?.toUpperCase()}
      </div>

      <div className="tweet-body">
        {/* Cabeçalho */}
        <div className="tweet-header">
          <span
            className="tweet-username"
            onClick={e => { e.stopPropagation(); navigate(`/perfil/${tweet.username}`); }}
          >
            {tweet.username}
          </span>
          <span className="tweet-handle">@{tweet.username}</span>
          <span className="tweet-time">· {formatarData(tweet.data_publicacao)}</span>
        </div>

        {/* Texto */}
        <p className="tweet-text">{tweet.conteudo}</p>

        {/* Imagem */}
        {tweet.imagem_url && (
          <img
            src={tweet.imagem_url}
            alt="Imagem do tweet"
            className="tweet-img"
            onClick={e => e.stopPropagation()}
          />
        )}

        {/* Ações */}
        <div className="tweet-footer">
          <button
            className={`tweet-action-btn ${euGostei ? 'liked' : ''}`}
            onClick={handleGosto}
            title={euGostei ? 'Retirar gosto' : 'Dar gosto'}
          >
            <span className="icon">{euGostei ? '❤️' : '🤍'}</span>
            {gostos > 0 && <span>{gostos}</span>}
          </button>

          {podeApagar && (
            <button
              className="tweet-action-btn delete"
              onClick={handleApagar}
              disabled={apagando}
              title="Apagar tweet"
            >
              <span className="icon">🗑️</span>
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
