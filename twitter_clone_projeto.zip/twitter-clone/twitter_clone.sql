-- ============================================================
-- BASE DE DADOS: Clone do Twitter/X
-- Disciplina: Sistemas Gestores de Bases de Dados I
-- Ano Letivo: 2025/2026
-- ============================================================

CREATE DATABASE IF NOT EXISTS twitter_clone CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE twitter_clone;

-- ============================================================
-- TABELA: UTILIZADOR
-- RI1: utilizador_id é chave primária, auto-incrementada
-- RI2: username é único e não pode ser NULL
-- RI3: email é único e não pode ser NULL
-- RI4: password_hash não pode ser NULL
-- RI5: data_registo assume o valor atual por omissão
-- RI6: is_admin assume 0 (false) por omissão
-- RI7: ativo assume 1 (true) por omissão
-- ============================================================
CREATE TABLE UTILIZADOR (
    utilizador_id   INT             NOT NULL AUTO_INCREMENT,
    username        VARCHAR(50)     NOT NULL,
    email           VARCHAR(100)    NOT NULL,
    password_hash   VARCHAR(255)    NOT NULL,
    bio             TEXT,
    foto_perfil     VARCHAR(500),
    data_registo    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_admin        TINYINT(1)      NOT NULL DEFAULT 0,
    ativo           TINYINT(1)      NOT NULL DEFAULT 1,
    CONSTRAINT PK_UTILIZADOR PRIMARY KEY (utilizador_id),
    CONSTRAINT UQ_UTILIZADOR_username UNIQUE (username),
    CONSTRAINT UQ_UTILIZADOR_email UNIQUE (email),
    CONSTRAINT CK_UTILIZADOR_is_admin CHECK (is_admin IN (0, 1)),
    CONSTRAINT CK_UTILIZADOR_ativo CHECK (ativo IN (0, 1))
);

-- ============================================================
-- TABELA: TWEET
-- RI8: tweet_id é chave primária, auto-incrementada
-- RI9: conteudo não pode ser NULL e máximo 280 caracteres
-- RI10: data_publicacao assume o valor atual por omissão
-- RI11: utilizador_id é chave estrangeira para UTILIZADOR
-- RI12: ao apagar utilizador, os seus tweets são apagados (CASCADE)
-- ============================================================
CREATE TABLE TWEET (
    tweet_id        INT             NOT NULL AUTO_INCREMENT,
    conteudo        VARCHAR(280)    NOT NULL,
    data_publicacao DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    utilizador_id   INT             NOT NULL,
    imagem_url      VARCHAR(500),
    CONSTRAINT PK_TWEET PRIMARY KEY (tweet_id),
    CONSTRAINT FK_TWEET_utilizador FOREIGN KEY (utilizador_id)
        REFERENCES UTILIZADOR(utilizador_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT CK_TWEET_conteudo CHECK (CHAR_LENGTH(conteudo) BETWEEN 1 AND 280)
);

-- ============================================================
-- TABELA: SEGUIDOR
-- RI13: (seguidor_id, seguido_id) é chave primária composta
-- RI14: seguidor_id é chave estrangeira para UTILIZADOR
-- RI15: seguido_id é chave estrangeira para UTILIZADOR
-- RI16: um utilizador não pode seguir-se a si próprio
-- RI17: data_follow assume o valor atual por omissão
-- ============================================================
CREATE TABLE SEGUIDOR (
    seguidor_id     INT             NOT NULL,
    seguido_id      INT             NOT NULL,
    data_follow     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT PK_SEGUIDOR PRIMARY KEY (seguidor_id, seguido_id),
    CONSTRAINT FK_SEGUIDOR_seguidor FOREIGN KEY (seguidor_id)
        REFERENCES UTILIZADOR(utilizador_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_SEGUIDOR_seguido FOREIGN KEY (seguido_id)
        REFERENCES UTILIZADOR(utilizador_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT CK_SEGUIDOR_autofollow CHECK (seguidor_id <> seguido_id)
);

-- ============================================================
-- TABELA: GOSTO
-- RI18: (utilizador_id, tweet_id) é chave primária composta
-- RI19: utilizador_id é chave estrangeira para UTILIZADOR
-- RI20: tweet_id é chave estrangeira para TWEET
-- RI21: data_gosto assume o valor atual por omissão
-- ============================================================
CREATE TABLE GOSTO (
    utilizador_id   INT             NOT NULL,
    tweet_id        INT             NOT NULL,
    data_gosto      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT PK_GOSTO PRIMARY KEY (utilizador_id, tweet_id),
    CONSTRAINT FK_GOSTO_utilizador FOREIGN KEY (utilizador_id)
        REFERENCES UTILIZADOR(utilizador_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_GOSTO_tweet FOREIGN KEY (tweet_id)
        REFERENCES TWEET(tweet_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ============================================================
-- INSERÇÃO DE DADOS DE EXEMPLO
-- ============================================================

-- Inserir utilizadores (password é hash de 'Password123!')
INSERT INTO UTILIZADOR (username, email, password_hash, bio, is_admin) VALUES
('admin',       'admin@twitterclone.pt',   '$2b$10$adminHashExemplo000001', 'Administrador do sistema', 1),
('joao_silva',  'joao@email.pt',           '$2b$10$hashExemplo000000000002', 'Programador apaixonado por tecnologia 💻', 0),
('maria_costa', 'maria@email.pt',          '$2b$10$hashExemplo000000000003', 'Estudante de Engenharia Informática', 0),
('pedro_gomes', 'pedro@email.pt',          '$2b$10$hashExemplo000000000004', 'Dev Full Stack | Madeira 🌺', 0),
('ana_ferreira','ana@email.pt',            '$2b$10$hashExemplo000000000005', 'UX Designer | Coffee lover ☕', 0),
('rui_martins', 'rui@email.pt',            '$2b$10$hashExemplo000000000006', 'Backend Developer | Python & SQL', 0),
('sofia_lopes', 'sofia@email.pt',          '$2b$10$hashExemplo000000000007', 'Data Scientist | ML enthusiast 🤖', 0),
('tiago_neves', 'tiago@email.pt',          '$2b$10$hashExemplo000000000008', 'Cloud Architect | Azure certified ☁️', 0);

-- Inserir tweets
INSERT INTO TWEET (conteudo, utilizador_id, imagem_url) VALUES
('Bem-vindos ao nosso clone do Twitter! Projeto de SGBD 2025/2026 🚀', 1, NULL),
('Hoje aprendi sobre normalização de bases de dados. Muito interessante!', 2, NULL),
('SQL é incrível! Consegui fazer uma query complexa com JOINs hoje 😊', 3, NULL),
('Deploy da base de dados no Azure feito com sucesso! ☁️', 4, NULL),
('Dica do dia: usem constraints nas vossas tabelas SQL para integridade dos dados!', 5, NULL),
('A trabalhar no projeto final de SGBD. Diagrama E-A quase pronto! 📊', 6, NULL),
('Machine Learning + SQL = combinação poderosa para análise de dados 🤖', 7, NULL),
('Tutorial de MySQL WorkBench disponível no Moodle. Confiram! 💡', 8, NULL),
('Alguém mais a ter dificuldades com a normalização para 3FN? 🤔', 3, NULL),
('Dica: o Azure oferece créditos gratuitos para estudantes! Muito útil para o projeto.', 4, 'https://exemplo.com/azure_logo.png'),
('Mais um tweet sobre desenvolvimento web e bases de dados relacionais!', 2, NULL),
('Integridade referencial é fundamental! Nunca se esqueçam das foreign keys.', 5, NULL);

-- Inserir relações de seguimento
INSERT INTO SEGUIDOR (seguidor_id, seguido_id) VALUES
(2, 1), -- joao segue admin
(3, 1), -- maria segue admin
(4, 1), -- pedro segue admin
(3, 2), -- maria segue joao
(4, 2), -- pedro segue joao
(5, 2), -- ana segue joao
(2, 3), -- joao segue maria
(4, 3), -- pedro segue maria
(5, 3), -- ana segue maria
(6, 3), -- rui segue maria
(2, 4), -- joao segue pedro
(3, 5), -- maria segue ana
(6, 5), -- rui segue ana
(7, 5), -- sofia segue ana
(3, 6), -- maria segue rui
(8, 7), -- tiago segue sofia
(2, 7), -- joao segue sofia
(5, 8); -- ana segue tiago

-- Inserir gostos
INSERT INTO GOSTO (utilizador_id, tweet_id) VALUES
(2, 1), (3, 1), (4, 1), (5, 1), -- tweet 1 (admin) com vários gostos
(3, 2), (4, 2), (5, 2),          -- tweet 2 (joao)
(2, 3), (4, 3),                   -- tweet 3 (maria)
(2, 4), (3, 4), (7, 4),           -- tweet 4 (pedro)
(2, 5), (3, 5), (6, 5),           -- tweet 5 (ana)
(3, 6), (5, 6),                   -- tweet 6 (rui)
(2, 7), (5, 7), (8, 7),           -- tweet 7 (sofia)
(3, 8), (6, 8),                   -- tweet 8 (tiago)
(2, 10),(3, 10),(6, 10);           -- tweet 10 (pedro com imagem)


-- ============================================================
-- OPERAÇÕES CRUD
-- ============================================================

-- ==================== CREATE (INSERT) ====================

-- C1: Registar novo utilizador
INSERT INTO UTILIZADOR (username, email, password_hash, bio)
VALUES ('novo_user', 'novouser@email.pt', '$2b$10$novoHashExemplo00001', 'Novo utilizador do sistema');

-- C2: Publicar um tweet
INSERT INTO TWEET (conteudo, utilizador_id)
VALUES ('O meu primeiro tweet no sistema! Que projeto incrível 🎉', 2);

-- C3: Publicar tweet com imagem
INSERT INTO TWEET (conteudo, utilizador_id, imagem_url)
VALUES ('A partilhar uma foto do nosso diagrama E-A 📊', 3, 'https://exemplo.com/diagrama_ea.png');

-- C4: Seguir um utilizador
INSERT INTO SEGUIDOR (seguidor_id, seguido_id)
VALUES (7, 4);  -- sofia segue pedro

-- C5: Dar gosto a um tweet
INSERT INTO GOSTO (utilizador_id, tweet_id)
VALUES (8, 3);  -- tiago gosta do tweet 3


-- ==================== READ (SELECT) ====================

-- R1: Feed do utilizador 2 (joao) - tweets de quem segue, ordem cronológica inversa
SELECT
    t.tweet_id,
    u.username,
    t.conteudo,
    t.imagem_url,
    t.data_publicacao,
    COUNT(g.tweet_id) AS total_gostos
FROM TWEET t
INNER JOIN UTILIZADOR u ON t.utilizador_id = u.utilizador_id
INNER JOIN SEGUIDOR s ON s.seguido_id = t.utilizador_id
LEFT JOIN GOSTO g ON g.tweet_id = t.tweet_id
WHERE s.seguidor_id = 2
GROUP BY t.tweet_id, u.username, t.conteudo, t.imagem_url, t.data_publicacao
ORDER BY t.data_publicacao DESC;

-- R2: Perfil de um utilizador com contagem de tweets, seguidores e seguidos
SELECT
    u.utilizador_id,
    u.username,
    u.bio,
    u.foto_perfil,
    u.data_registo,
    (SELECT COUNT(*) FROM TWEET WHERE utilizador_id = u.utilizador_id) AS total_tweets,
    (SELECT COUNT(*) FROM SEGUIDOR WHERE seguido_id = u.utilizador_id)  AS total_seguidores,
    (SELECT COUNT(*) FROM SEGUIDOR WHERE seguidor_id = u.utilizador_id) AS total_seguindo
FROM UTILIZADOR u
WHERE u.username = 'joao_silva';

-- R3: Top 5 tweets com mais gostos
SELECT
    t.tweet_id,
    u.username,
    t.conteudo,
    COUNT(g.tweet_id) AS total_gostos
FROM TWEET t
INNER JOIN UTILIZADOR u ON t.utilizador_id = u.utilizador_id
LEFT JOIN GOSTO g ON g.tweet_id = t.tweet_id
GROUP BY t.tweet_id, u.username, t.conteudo
ORDER BY total_gostos DESC
LIMIT 5;

-- R4: Listar todos os seguidores de um utilizador
SELECT
    u.utilizador_id,
    u.username,
    u.bio,
    s.data_follow
FROM UTILIZADOR u
INNER JOIN SEGUIDOR s ON s.seguidor_id = u.utilizador_id
WHERE s.seguido_id = 2
ORDER BY s.data_follow DESC;

-- R5: Verificar se utilizador A segue utilizador B
SELECT EXISTS (
    SELECT 1 FROM SEGUIDOR
    WHERE seguidor_id = 2 AND seguido_id = 3
) AS ja_segue;

-- R6: Backoffice - listar todos os utilizadores (admin)
SELECT
    u.utilizador_id,
    u.username,
    u.email,
    u.is_admin,
    u.ativo,
    u.data_registo,
    COUNT(t.tweet_id) AS total_tweets
FROM UTILIZADOR u
LEFT JOIN TWEET t ON t.utilizador_id = u.utilizador_id
GROUP BY u.utilizador_id, u.username, u.email, u.is_admin, u.ativo, u.data_registo
ORDER BY u.data_registo DESC;

-- R7: Backoffice - listar todos os tweets com autor (admin)
SELECT
    t.tweet_id,
    u.username,
    t.conteudo,
    t.imagem_url,
    t.data_publicacao,
    COUNT(g.tweet_id) AS total_gostos
FROM TWEET t
INNER JOIN UTILIZADOR u ON t.utilizador_id = u.utilizador_id
LEFT JOIN GOSTO g ON g.tweet_id = t.tweet_id
GROUP BY t.tweet_id, u.username, t.conteudo, t.imagem_url, t.data_publicacao
ORDER BY t.data_publicacao DESC;


-- ==================== UPDATE ====================

-- U1: Atualizar bio de um utilizador
UPDATE UTILIZADOR
SET bio = 'Bio atualizada: Full Stack Developer | Madeira 🌺'
WHERE utilizador_id = 4;

-- U2: Atualizar foto de perfil
UPDATE UTILIZADOR
SET foto_perfil = 'https://exemplo.com/fotos/joao_nova.jpg'
WHERE utilizador_id = 2;

-- U3: Desativar utilizador (soft delete - admin)
UPDATE UTILIZADOR
SET ativo = 0
WHERE utilizador_id = 9;

-- U4: Reativar utilizador (admin)
UPDATE UTILIZADOR
SET ativo = 1
WHERE utilizador_id = 9;

-- U5: Atualizar conteúdo de um tweet (pelo próprio autor)
UPDATE TWEET
SET conteudo = 'Tweet editado: Deploy no Azure concluído com sucesso! ☁️✅'
WHERE tweet_id = 4 AND utilizador_id = 4;

-- U6: Promover utilizador a administrador
UPDATE UTILIZADOR
SET is_admin = 1
WHERE utilizador_id = 6;

-- U7: Atualizar password (simulado - normalmente feito via aplicação)
UPDATE UTILIZADOR
SET password_hash = '$2b$10$novoHashSeguro000000001'
WHERE utilizador_id = 2;


-- ==================== DELETE ====================

-- D1: Apagar tweet (pelo autor)
DELETE FROM TWEET
WHERE tweet_id = 13 AND utilizador_id = 2;

-- D2: Deixar de seguir um utilizador
DELETE FROM SEGUIDOR
WHERE seguidor_id = 7 AND seguido_id = 4;

-- D3: Retirar gosto a um tweet
DELETE FROM GOSTO
WHERE utilizador_id = 8 AND tweet_id = 3;

-- D4: Apagar utilizador e todos os seus dados em cascata (admin)
DELETE FROM UTILIZADOR
WHERE utilizador_id = 9;

-- D5: Apagar todos os tweets de um utilizador (admin)
DELETE FROM TWEET
WHERE utilizador_id = 9;

-- D6: Apagar tweet pelo administrador
DELETE FROM TWEET
WHERE tweet_id = 14;

-- D7: Remover todos os gostos de um tweet antes de o apagar
DELETE FROM GOSTO
WHERE tweet_id = 14;
